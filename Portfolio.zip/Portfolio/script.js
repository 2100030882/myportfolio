// small interactive bits: mobile menu toggle + current year
document.getElementById('year').textContent = new Date().getFullYear();
const toggle = document.getElementById('menuToggle');
const mobileNav = document.getElementById('mobileNav');


if (toggle) {
    toggle.addEventListener('click', () => {
        mobileNav.classList.toggle('open');
    });
}


// close mobile nav on link click
mobileNav.querySelectorAll('a').forEach(a =>
    a.addEventListener('click', () => mobileNav.classList.remove('open'))
);